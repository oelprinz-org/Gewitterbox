void calculateSecondaryFuel();
void calculateSecondarySpark();
byte getVE2();
byte getAdvance2();